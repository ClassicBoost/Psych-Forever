Put your custom character icons here!
The image resolution must have a minimal of 300x150

For winning icons, image resolution have a minimal of 450x150