There is a lot of changes within the files so if you are from Psych Engine
read through all of this to put all of the new files at.

Charts, Dialogue, and Song Scripts belong in the Songs folder
menubackgrounds belong in the "menus/story/backgrounds/" folder (DO NOT ADD "menu_")
menucharacters belong in the "menus/story/characters/" folder
storymenu belongs in the "menus/story/weeks/" folder
dialogue protraits belong in the "dialogue/characters/" folder

Not really good with explaining but you know what I mean.