Put your custom character icons here!
Icons does not require "icon-" at the start
The image resolution must have a minimal of 300x150

For winning icons they must have a minimal of 450x150