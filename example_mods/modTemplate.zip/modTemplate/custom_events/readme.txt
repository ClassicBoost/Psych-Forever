Add your custom event's .txt file and .lua file here

The .txt file is the event's description on Chart Editor